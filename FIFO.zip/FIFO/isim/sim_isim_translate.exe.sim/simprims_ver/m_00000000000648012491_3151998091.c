/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_0587731369_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0587731369", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0587731369.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0107171445_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0107171445", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0107171445.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0349626779_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0349626779", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0349626779.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1746715686_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1746715686", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1746715686.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0813683824_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0813683824", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0813683824.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1376498402_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1376498402", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1376498402.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0363579442_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0363579442", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0363579442.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2423752423_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2423752423", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2423752423.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2904010583_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2904010583", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2904010583.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3621256247_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3621256247", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3621256247.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3760942834_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3760942834", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3760942834.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1869323090_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1869323090", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1869323090.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0576150263_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0576150263", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0576150263.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2599107986_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2599107986", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2599107986.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1710694439_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1710694439", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1710694439.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0523727687_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0523727687", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0523727687.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2995781695_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2995781695", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2995781695.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0304550198_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0304550198", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0304550198.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0793196678_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0793196678", "isim/sim_isim_translate.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0793196678.didat");
}
