/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    simprims_ver_m_00000000003359274523_2662658903_init();
    simprims_ver_m_00000000001255213976_2021654676_init();
    simprims_ver_m_00000000000648012491_3151998091_init();
    simprims_ver_m_00000000001867363923_1692233196_init();
    simprims_ver_u_00000000000017755009_3216321564_init();
    simprims_ver_m_00000000003963788642_2501315080_init();
    simprims_ver_m_00000000001255213976_3226743947_init();
    simprims_ver_m_00000000003719362827_1840704098_init();
    simprims_ver_u_00000000002212670773_1323274903_init();
    simprims_ver_m_00000000001160127574_0897309690_init();
    simprims_ver_m_00000000003598591109_3452726508_init();
    simprims_ver_m_00000000003598591109_0234073423_init();
    simprims_ver_m_00000000003598591109_3914519671_init();
    simprims_ver_m_00000000003598591109_3249491193_init();
    simprims_ver_m_00000000003598591109_3418928570_init();
    simprims_ver_m_00000000003598591109_2871523764_init();
    simprims_ver_m_00000000003598591109_0675294044_init();
    simprims_ver_m_00000000003598591109_0844360943_init();
    simprims_ver_m_00000000003598591109_1218397072_init();
    simprims_ver_m_00000000003598591109_3442068614_init();
    simprims_ver_m_00000000003598591109_0195502421_init();
    simprims_ver_m_00000000003598591109_0878193945_init();
    simprims_ver_m_00000000003598591109_2129103041_init();
    simprims_ver_m_00000000003598591109_2899389071_init();
    simprims_ver_m_00000000003598591109_3360225898_init();
    simprims_ver_m_00000000003598591109_1159575906_init();
    simprims_ver_m_00000000003598591109_2101667337_init();
    simprims_ver_m_00000000003598591109_1823105841_init();
    simprims_ver_m_00000000003598591109_3440194837_init();
    simprims_ver_m_00000000003598591109_0576437995_init();
    simprims_ver_m_00000000003598591109_1433350400_init();
    simprims_ver_m_00000000003598591109_4144967518_init();
    simprims_ver_m_00000000003598591109_1346676151_init();
    simprims_ver_m_00000000003598591109_1207941100_init();
    simprims_ver_m_00000000003598591109_0080085863_init();
    simprims_ver_m_00000000003598591109_0193729128_init();
    simprims_ver_m_00000000003598591109_1821402742_init();
    simprims_ver_u_00000000001790370653_1131516744_init();
    simprims_ver_m_00000000000452859522_3752318385_init();
    simprims_ver_m_00000000000589308365_3009709386_init();
    simprims_ver_m_00000000000126354981_1080494567_init();
    simprims_ver_m_00000000000126354981_0818475687_init();
    work_m_00000000002938707670_2012599300_init();
    work_m_00000000004116644882_3553469787_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000004116644882_3553469787");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
