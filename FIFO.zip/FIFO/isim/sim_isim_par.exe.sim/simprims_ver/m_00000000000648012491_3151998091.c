/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_1915980053_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1915980053", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1915980053.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3079976859_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3079976859", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3079976859.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0300137519_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0300137519", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0300137519.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0351939305_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0351939305", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0351939305.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0621949044_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0621949044", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0621949044.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1119503152_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1119503152", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1119503152.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2934554973_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2934554973", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2934554973.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2024809024_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2024809024", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2024809024.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3018650085_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3018650085", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3018650085.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2313588885_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2313588885", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2313588885.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3810615382_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3810615382", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3810615382.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1706365688_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1706365688", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1706365688.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1634858887_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1634858887", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1634858887.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3890578729_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3890578729", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3890578729.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0679326707_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0679326707", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0679326707.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0897090379_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0897090379", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0897090379.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4263792878_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4263792878", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4263792878.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0196478788_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0196478788", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0196478788.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3236615393_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3236615393", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3236615393.didat");
}
