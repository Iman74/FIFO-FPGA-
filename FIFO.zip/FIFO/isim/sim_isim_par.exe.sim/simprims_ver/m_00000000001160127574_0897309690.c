/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000001160127574_0897309690_1103899336_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1103899336", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1103899336.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3664340647_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3664340647", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3664340647.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2918691927_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2918691927", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2918691927.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0911407160_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0911407160", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0911407160.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1120539063_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1120539063", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1120539063.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3647954392_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3647954392", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3647954392.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2935066408_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2935066408", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2935066408.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0894747463_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0894747463", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0894747463.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1203788854_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1203788854", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1203788854.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3697610841_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3697610841", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3697610841.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1594169979_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1594169979", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1594169979.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3298842132_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3298842132", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3298842132.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3007218916_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3007218916", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3007218916.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0681298059_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0681298059", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0681298059.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1543708932_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1543708932", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1543708932.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3349572971_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3349572971", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3349572971.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2956509083_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2956509083", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2956509083.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0731771892_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0731771892", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0731771892.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1493789829_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1493789829", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1493789829.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3266060522_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3266060522", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3266060522.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1110826857_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1110826857", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1110826857.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3650130694_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3650130694", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3650130694.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2903014025_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2903014025", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2903014025.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1560080346_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1560080346", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1560080346.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3344540597_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3344540597", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3344540597.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3015789114_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3015789114", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3015789114.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1339318768_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1339318768", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1339318768.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3564187039_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3564187039", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3564187039.didat");
}
