/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif



static void Gate_29_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 2504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1344U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 2904);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 2824);
    *((int *)t9) = 1;

LAB1:    return;
}


extern void simprims_ver_m_00000000001255213976_0395863204_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0395863204", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0395863204.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0428553500_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0428553500", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0428553500.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0486951342_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0486951342", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0486951342.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0482616217_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0482616217", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0482616217.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0375000723_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0375000723", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0375000723.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0407461675_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0407461675", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0407461675.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_3226763193_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_3226763193", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_3226763193.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_2352497623_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_2352497623", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_2352497623.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0058242679_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0058242679", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0058242679.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0045800512_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0045800512", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0045800512.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0437248370_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0437248370", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0437248370.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_1114435876_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_1114435876", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_1114435876.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_1076514685_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_1076514685", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_1076514685.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0466455365_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0466455365", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0466455365.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0511876544_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0511876544", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0511876544.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_0524351479_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_0524351479", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_0524351479.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_1312366277_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_1312366277", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_1312366277.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_1341879538_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_1341879538", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_1341879538.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000001255213976_3226743947_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000001255213976_3226743947", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000001255213976_3226743947.didat");
	xsi_register_executes(pe);
}
