/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_0502132496_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0502132496", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0502132496.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0488572414_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0488572414", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0488572414.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4137725761_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4137725761", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4137725761.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1073424414_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1073424414", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1073424414.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4200339088_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4200339088", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4200339088.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1546329380_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1546329380", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1546329380.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3417574413_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3417574413", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3417574413.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3111082672_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3111082672", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3111082672.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2093507646_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2093507646", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2093507646.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3669979018_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3669979018", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3669979018.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1293975203_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1293975203", "isim/sim_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1293975203.didat");
}
